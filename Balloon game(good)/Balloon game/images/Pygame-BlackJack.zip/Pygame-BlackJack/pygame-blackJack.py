from blackjack_classes import *
from constants import *
from math import sqrt
import pygame, time
pygame.init()
bet = 100
dealer = Dealer(bet)
player = Player(bet)
results = "null"    
screen=pygame.display.set_mode((800,600))
dealBool = True
background = pygame.image.load("img/background.jpg")
background = pygame.transform.scale(background,(800,600))
class Play:

    def hit():
        global results
        player.hit()
        #The class has a function that returns whether or not the dealer busts or gets blackjack or vice versa
        #The function is called when the player hits the space with the play object, in which case, the game would use transfer the bet accordingly
        #This will be added for every combination in the final game through the function. Global will be removed when everything is transfered into the classes file
        if player.count() == "Bust":
            results = "Dealer"
            play.deal()
        elif player.count() == "BlackJack":
            results = "Player"
            play.deal()
        redraw_screen()
        #Used to indicate who one with a conditional, "null" shows nothing
        results = "null"
    def hold():
        #While loop that makes continues to hit the dealer and redraw the screen to show it. If a person loses, the results variable is changed
        #The screen will be redrawed so the message will show, then change the variable to not show it again.
        #Global variable will be changed when the class play class is moved into the classes file (when it is complete)
        #For each of the events, the game will call the deal function which is in the same play class
        global results
        while True:

            time.sleep(0.5)
            redraw_screen()
            if dealer.count() == "Bust":
                results = "Player"
                redraw_screen()
                results = "null"
                play.deal()
                break
            #Checks whether the dealer hand value is greater than 17 (since it can't hit if it is greater than 17, then checks if it is greater than than the player's and the dev has not busted)
            elif dealer.handValue >= 17 and dealer.handValue <= 21:
                if dealer.handValue > player.handValue:
                    results = "Dealer"
                    redraw_screen()
                    results = "null"
                else:
                    results = "Player"
                    redraw_screen()
                    results = "null"
                play.deal()
                break
                
            elif dealer.count() == "BlackJack":
                results = "Dealer"
                redraw_screen()
                results = "null"
                play.deal()
                break
            dealer.hit()
    def bettingSystem():
        #Betting system which has a circle act as a slider by staying at the same y value, but its x value is equal to the user cursor
        betX = 150
        mouseHold = True
        while True:
             mouseX, mouseY = pygame.mouse.get_pos()
             percentage = (betX-150)/1.5
             playerBet = round(percentage*player.money/100)
             if mouseHold:
                 if mouseX > 300:
                     betX = 300
                 elif mouseX < 150:
                     betX = 150
                 else:
                    betX = mouseX
                    
             for event in pygame.event.get():
                    #Checks if user x's out the window
                    if event.type == pygame.QUIT:
                        betMenu = False
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if distance(mouseX, mouseY, betX, 300) < 10:
                            mouseHold = True
                        elif distance(mouseX, mouseY, betX, 300) > 10:
                            mouseHold = False
             keys = pygame.key.get_pressed()
             #Sets the bet variables
             if keys[pygame.K_RETURN]:
                 play.deal()
                 player.bet = playerBet
                 dealer.bet = playerBet
                 break
    
             pygame.time.delay(25)
             screen.fill(green)
             pygame.draw.line(screen, white, (150,300), (300, 300), 5)
             pygame.draw.circle(screen, white, (betX, 300), 10)
             percentage = (betX-150)/1.5
             betPercentage = textfont.render((str(round(percentage))+ "%"), 1, white)
             playerBet = round(percentage*player.money/100)
             #Calculates the percentage by subtracting the x value by 150 (since the line starts at 150) and dividing it by 300 (the line is 150 px long and starts at 150 px)\
             #The percentage is then multiplied by the total money.
             #This will be changed to betting with chips
             playerBetText = textfont.render("Bet Value: " + str(playerBet), 1, white)
             screen.blit(betPercentage, (betX-10, 275))
             screen.blit(playerBetText, (150, 200))
             pygame.display.update()

             

                    

        
    def deal():
        #Clears the lists to start the game again, then hits 2 for player and dealer.
        dealBool = False
        player.handList.clear()
        player.cardPic.clear()
        dealer.handList.clear()
        dealer.cardPic.clear()
        player.hit()
        dealer.hit()
        time.sleep(0.5)
        redraw_screen()
        player.hit()
        dealer.hit()
        time.sleep(0.5)
        redraw_screen()
    def double():
        #Gonna be fixed using a method in the actual classes. No keyboard hotkey
        player.bet*=2
        dealer.bet *= 2

    def insurance():
        #Gonna be fixed using a method in the actual classes. No keyboard hotkey
        player.bet /= 2
        dealer.bet += dealer.bet/2
        
play = Play

playerPicList = []
dealerPicList = []
def distance(x1, y1, x2, y2):
    return sqrt((x1-x2)**2 + (y1-y2)**2)
    

def redraw_screen():
    #Loads the different types of hud
    menuFont = font.render(("X - Exit, SPACE - Hit, H - Hold, F - Double down, E - Change Bet, D - New deal"), 1, white)
    betAmount = textfont.render(("Bet: $" + str(player.bet)), 1, white)
    playerScore = textfont.render(("Player money: $" + str(player.money)), 1, white)
    playerHand = textfont.render(("Hand Value: " + str(player.handValue)), 1, white)
    dealerScore = textfont.render(("dealer money: $" + str(dealer.money)), 1, white)
    dealerHand = textfont.render(("Hand Value: " + str(dealer.handValue)), 1, white)
    playerResult = blackjack.render("Player won!", 1, blue)
    dealerResult = blackjack.render("Dealer won!", 1, dark_red)
    screen.blit(background,(0,0))
    #Checks if the player holds, if so, would blit the hand value of the dealer
    if not dealBool:
        screen.blit(dealerHand, (50, 50))
    screen.blit(menuFont, (0, 550))
    screen.blit(playerScore, (10, 300))
    screen.blit(playerHand, (50, 380))
    screen.blit(dealerScore, (10, 130))
    screen.blit(betAmount, (450, 300))
    
    screen.blit(backCard, (10, 150))
    playerPicList.clear()
    dealerPicList.clear()
    #Loads the card images by putting a variable to the list of picture file link from the classes
    for i in range(len(player.cardPic)):
        card = pygame.image.load(player.cardPic[i])
        playerPicList.append(card)
    for j in range(len(dealer.cardPic)):
        dCard = pygame.image.load(dealer.cardPic[j])
        dealerPicList.append(dCard)
    index = 250
    for k in range(len(playerPicList)): 
        screen.blit(playerPicList[k], (index, 400))
        index += 100
    index = 250
    for l in range(len(dealerPicList)):
            screen.blit(dealerPicList[l], (index, 50))
            if dealBool:
               screen.blit(backCard, (350, 50))
            index += 100
    if results == "Player":
        screen.blit(playerResult, (350, 500))
    elif results == "Dealer":
        screen.blit(dealerResult,(350, 100))
  
    
        
    pygame.display.update()


        
gameLoop = True
#Deals the cards initially using the method
play.deal()
while gameLoop:
    #All the keys are hotkeyed to the different functions in the play class.
     for event in pygame.event.get():
            #Checks if user x's out the window
            if event.type == pygame.QUIT:
                gameLoop = False
     keys = pygame.key.get_pressed()
     if keys[pygame.K_SPACE]: 
         play.hit()
     if keys[pygame.K_d]:
         #Registers as player losing bet
         player.money -= player.bet
         play.deal()
     if keys[pygame.K_x]:
         #Kills the program
         gameLoop = False
     if keys[pygame.K_h]:
         #Changes the boolean such that it will blit the images hidden when the game starts
         dealBool = False
         play.hold()
     if keys[pygame.K_c]:
         player.changeBet
     if keys[pygame.K_e]:
         #If the player wants a new bet, will remove the money since it registers as losing the bet. Gonna use a boolean to decipher between if the game is about the begin to not remove money.
         player.money -= player.bet
         play.bettingSystem()
     #The game is delayed so that a key tap wouldn't render any more. 
     pygame.time.delay(150)
     redraw_screen()

pygame.quit()
            
        
    
