from constants import *
import pygame, random
pygame.init()

class Deck:
    def __init__(self):
        self.cards = []
        #Sets the "deck" by using a for loop for the card values and suits
        self.build()
    def build(self):
        for value in RANKS:
            for suit in SUITS:
                #Putting both the suits and ranks together (as done in the pictures)
                #Done so it can be loaded into the main game with another string concatenation
                self.cards.append([value, suit])
        #Randomizes the card deck each time
        random.shuffle(self.cards)


class Dealer():
    def __init__(self, bet):
        self.money = 1000
        self.cardPic = []
        self.handValue = 0
        self.handList = []
        self.bet = bet
        self.deck = Deck()
        
    def count(self):
        self.handValue = 0
        aceCount = 0
        for value in self.handList:
            if value == "A":
                aceCount += 1
            elif value in "JQK":
                self.handValue += 10
            else:
                value = int(value)
                self.handValue += value
        for i in range(aceCount):
            #Checks to see if an ace would make the hand greater than 21, if so, changes the value to 1
            if self.handValue + 11 > 21:
                self.handValue += 1
            else:
                self.handValue += 11            
        #Checks if the hand busts or blackjack (compares the two hands in the play class in the main loop    
        if self.handValue > 21:
            self.money -= self.bet
            return "Bust"
        elif self.handValue == 21:
            return "BlackJack"
        

            
    def hit(self):
        #Appends the first "card" in the deck and only its value.
        self.handList.append(self.deck.cards[0][0])
        #Appends the cardPic list with the files by adding the value and suit with each other
        self.cardPic.append(("img/"+ "".join(self.deck.cards[0][0] + self.deck.cards[0][1]) + ".png"))
        #Removes the first card 
        self.deck.cards.pop(0)
        #Each hit, it uses the count method to see if the player or dealer busts
        self.count()

        

        
        


class Player(Dealer):
    #Will be expanded upon, doesn't work at the moment. Will use a list to track the two cards and switch the index using a boolean
    def split(self):
        handList1 = self.handList[:len(self.handList)//2]
        handList2 = self.handList[len(self.handList)//2:]
        splitList = [handList1, handList2]


        







        
        
